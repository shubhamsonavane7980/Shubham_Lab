package practical;

public class Test { 
void m1() { 
System.out.println("same package"); 
} 
} 
