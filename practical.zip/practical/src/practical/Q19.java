package practical;

import demo.*; 
public class Q19 extends Hello{ 
public static void main(String[] args) { 
Q19 obj=new Q19(); 
obj.display(); 
Test t1=new Test(); 
t1.m1(); 
} 
}
