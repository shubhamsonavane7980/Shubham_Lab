package demo;

public class Hello { 
protected String name="hello world"; 
protected void display() { 
System.out.println("demo package"); 
System.out.println(name); 
} 
} 
